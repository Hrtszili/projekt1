# Create a simple IF function that compares nativeVLAN and dataVLAN values and prints result.

NVLAN = input("Give me a number:")
Dvlan = input("Give me another number:")

if NVLAN > Dvlan:
    print("Native Vlan is greater than Data Vlan.")
elif NVLAN == Dvlan:
    print("The two Vlans is equal")
else:
    print("Data Vlan is greater than Nativ Vlan. ")
