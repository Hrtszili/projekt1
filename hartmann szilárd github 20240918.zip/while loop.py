'''
Write Python program :
    get an input for a number to count to
    if input is "q" or "quit", the program exits
    else write numbers from 1 to the number in one line, separated by space and goes back to the input
'''

number = int(input("Please write a number"))
if number is quit:
    print("")
