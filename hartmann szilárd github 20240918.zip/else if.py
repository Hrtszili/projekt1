'''
The standard ACL numbers are between 1 and 99 (inclusive)
The extended ACL numbers are between 100 199 (inclusive)
Other ACL numbers are nor standard nor extended.
Input an ACL number and categorize it!
'''


ACL = input("Input an ACL number:")

if ACL in range(1,99):
    print("This is standrard ACL Number")

elif ACL in range(100,199):
    print("this is Extended ACL number")

else:
    print("this is not standard or Extended")

