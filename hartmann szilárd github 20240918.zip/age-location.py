"""
Write code to get output below:

What is your first name? First
What is your last name? Last
What is your location? Texas
What is your age? 54
Hi First Last! Your location is Texas and you are 54 years old.
>>>
"""
First = input("What is your first name?:")
Last = input("What is your last name?:")
Location = input("What is your location?:")
Age = input("What is your age?")

print("Hi",First,Last,"Your location is",Location,"And you are",Age,"years old.")


