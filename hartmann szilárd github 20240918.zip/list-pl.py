# Create a list of the BRICS countries :Brazil, Russia, India, China, South Africa
countries=['Brazil','Russia','India','China','South Africa']
print("Countries:",", ".join(countries))


"""Create a dictionary of BRICS capitals.
Note that South Africa has 3 capitals. Brasilia, Moscow, New Delhi, (Pretoria, Cape Town, Bloemfontein)
"""


capitals=['Brasilia', 'Moscow', 'New Delhi', 'Pretoria', 'Cape Town', 'Bloemfontein']
print("Capitals:",", ".join(capitals))



# Print the list and dictionary

"""
What response did you get?
Why did the list and dictionary contents not print?
Fix the code and run the script again.
"""


capitals.remove('Brasilia')
capitals.remove('Moscow')
capitals.remove('New Delhi')
print("The 3 South African capitals is: " ,", ".join(capitals))

"""
Why did you get an error for the 2nd capital of South Africa?
Hint: Check the syntax for the index value.
"""

